<?php

namespace Chatify\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    //
}
